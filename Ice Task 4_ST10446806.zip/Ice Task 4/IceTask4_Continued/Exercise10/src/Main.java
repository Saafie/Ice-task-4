import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Division division;
        System.out.print("Do you want to create a DomesticDivision (D) or InternationalDivision (I)? ");
        String type = scanner.next();
        if (type.equalsIgnoreCase("D")) {
            System.out.print("Enter the division name: ");
            String divisionName = scanner.next();
            System.out.print("Enter the account number: ");
            String accountNumber = scanner.next();
            System.out.print("Enter the state: ");
            String state = scanner.next();
            division = new DomesticDivision(divisionName, accountNumber, state);
        } else if (type.equalsIgnoreCase("I")) {
            System.out.print("Enter the division name: ");
            String divisionName = scanner.next();
            System.out.print("Enter the account number: ");
            String accountNumber = scanner.next();
            System.out.print("Enter the country: ");
            String country = scanner.next();
            System.out.print("Enter the language: ");
            String language = scanner.next();
            division = new InternationalDivision(divisionName, accountNumber, country, language);
        } else {
            System.out.println("Invalid input. Exiting...");
            return;
        }
        division.display();
    }
}