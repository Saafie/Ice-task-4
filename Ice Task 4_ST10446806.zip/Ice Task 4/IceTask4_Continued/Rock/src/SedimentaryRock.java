public class SedimentaryRock extends Rock {
    public SedimentaryRock(int sampleNumber, double weight) {
        super(sampleNumber, weight);
        this.description = "Sedimentary rocks are formed from the accumulation and compression of mineral and organic particles.";
    }
}
