public class IgneousRock extends Rock {
    public IgneousRock(int sampleNumber, double weight) {
        super(sampleNumber, weight);
        this.description = "Igneous rocks are formed from the cooling and solidification of magma or lava.";
    }
}

