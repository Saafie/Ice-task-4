//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the type of Rock (U, I, S, or M): ");
        String type = scanner.next();

        Rock rock;
        if (type.equalsIgnoreCase("U")) {
            rock = new Rock(0, 0);
        } else {
            System.out.print("Enter the sample number: ");
            int sampleNumber = scanner.nextInt();
            System.out.print("Enter the weight: ");
            double weight = scanner.nextDouble();

            switch (type.toUpperCase()) {
                case "I":
                    rock = new IgneousRock(sampleNumber, weight);
                    break;
                case "S":
                    rock = new SedimentaryRock(sampleNumber, weight);
                    break;
                case "M":
                    rock = new MetamorphicRock(sampleNumber, weight);
                    break;
                default:
                    rock = new Rock(0, 0);
            }
        }

        displayRockDetails(rock);
    }

    public static void displayRockDetails(Rock rock) {
        System.out.println("Sample Number: " + rock.getSampleNumber());
        System.out.println("Description: " + rock.getDescription());
        System.out.println("Weight: " + rock.getWeight() + " grams");
    }
}