public interface Turner {
    void turn();
}
