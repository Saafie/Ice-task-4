public class LeafPagePancake {
}
class Leaf implements Turner {
    @Override
    public void turn() {
        System.out.println("Changing colors");
    }
}
class Page implements Turner {
    @Override
    public void turn() {
        System.out.println("Going to the next page");
    }
}
class Pancake implements Turner {
    @Override
    public void turn() {
        System.out.println("Flipping");
    }
}
class SteeringWheel implements Turner {
    @Override
    public void turn() {
        System.out.println("Turning the wheel");
    }
}

class Key implements Turner {
    @Override
    public void turn() {
        System.out.println("Turning the key");
    }
}

