import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Turner turner;
        while (true) {
            System.out.print("Enter the type of turner (L for Leaf, P for Page, C for Pancake, or Q to quit): ");
            String type = scanner.next();

            if (type.equalsIgnoreCase("Q")) {
                break;
            }
            switch (type) {
                case "L":
                    turner = new Leaf();
                    break;
                case "P":
                    turner = new Page();
                    break;
                case "C":
                    turner = new Pancake();
                    break;
                default:
                    System.out.println("Invalid input. Please try again.");
                    continue;
            }
            turner.turn();
        }
    }
}