public class Classes {

}
class Machine implements Runner {
    @Override
    public void run() {
        System.out.println("A machine runs on electricity or fuel.");
    }
}

class Athlete implements Runner {
    @Override
    public void run() {
        System.out.println("An athlete runs to compete in a race or to stay physically fit.");
    }
}

class PoliticalCandidate implements Runner {
    @Override
    public void run() {
        System.out.println("A political candidate runs for office to gain a position of power.");
    }
}
