import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Runner runner;

        while (true) {
            System.out.print("Enter the type of runner (M for Machine, A for Athlete, P for Political Candidate, or Q to quit): ");
            String type = scanner.next();

            if (type.equalsIgnoreCase("Q")) {
                break;
            }

            switch (type) {
                case "M":
                    runner = new Machine();
                    break;
                case "A":
                    runner = new Athlete();
                    break;
                case "P":
                    runner = new PoliticalCandidate();
                    break;
                default:
                    System.out.println("Invalid input. Please try again.");
                    continue;
            }

            runner.run();
        }
    }
}