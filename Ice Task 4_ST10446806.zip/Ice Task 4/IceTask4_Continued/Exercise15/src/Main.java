import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the description of the invention: ");
        String description = scanner.nextLine();
        System.out.print("Enter the name of the inventor: ");
        String inventorName = scanner.nextLine();
        System.out.print("Enter the country of origin of the inventor: ");
        String countryOfOrigin = scanner.nextLine();
        System.out.print("Enter the date of the invention (in YYYY-MM-DD format): ");
        String dateStr = scanner.nextLine();
        LocalDate date = LocalDate.parse(dateStr, DateTimeFormatter.ISO_DATE);
        Inventor inventor = new Inventor(inventorName, countryOfOrigin);
        Invention invention = new Invention(description, inventor, date);
        System.out.println(invention.toString());
    }
}