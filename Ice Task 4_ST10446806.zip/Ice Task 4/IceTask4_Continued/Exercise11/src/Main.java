import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Blanket blanket = new Blanket();
        System.out.println("Initial Blanket: " + blanket.toString());

        while (true) {
            System.out.print("Enter a material (or Q to quit): ");
            String material = scanner.next();

            if (material.equalsIgnoreCase("Q")) {
                break;
            }

            blanket.setMaterial(material);
            System.out.println("Blanket: " + blanket.toString());

            System.out.print("Enter a size: ");
            String size = scanner.next();
            blanket.setSize(size);
            System.out.println("Blanket: " + blanket.toString());
        }

        ElectricBlanket electricBlanket = new ElectricBlanket();
        System.out.println("Initial Electric Blanket: " + electricBlanket.toString());

        while (true) {
            System.out.print("Enter a material (or Q to quit): ");
            String material = scanner.next();

            if (material.equalsIgnoreCase("Q")) {
                break;
            }

            electricBlanket.setMaterial(material);
            System.out.println("Electric Blanket: " + electricBlanket.toString());

            System.out.print("Enter a size: ");
            String size = scanner.next();
            electricBlanket.setSize(size);
            System.out.println("Electric Blanket: " + electricBlanket.toString());

            System.out.print("Enter the number of heat settings: ");
            int heatSettings = scanner.nextInt();
            electricBlanket.setHeatSettings(heatSettings);
            System.out.println("Electric Blanket: " + electricBlanket.toString());

            System.out.print("Does the Electric Blanket have automatic shutoff? (Y/N): ");
            boolean automaticShutoff = scanner.next().equalsIgnoreCase("Y");
            electricBlanket.setAutomaticShutoff(automaticShutoff);
            System.out.println("Electric Blanket: " + electricBlanket.toString());
        }
    }
}