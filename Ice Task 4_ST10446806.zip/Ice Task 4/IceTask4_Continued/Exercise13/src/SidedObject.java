public interface SidedObject {
    void displaySides();
}