public class SquareTrianglesubclasses {
    class Square extends GeometricFigure {
        private double area;

        public Square(double sideLength) {
            super(sideLength, sideLength, "Square");
            this.area = calculateArea();
        }

        @Override
        public double calculateArea() {
            return height * width;
        }

        @Override
        public void displaySides() {

        }

        public double getArea() {
            return area;
        }
    }

    abstract class Triangle extends GeometricFigure {
        private double area;

        public Triangle(double base, double height) {
            super(height, base, "Triangle");
            this.area = calculateArea();
        }

        @Override
        public double calculateArea() {
            return 0.5 * height * width;
        }

        public double getArea() {
            return area;
        }
    }
}
