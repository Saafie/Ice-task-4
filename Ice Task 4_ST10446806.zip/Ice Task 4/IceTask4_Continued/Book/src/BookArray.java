import java.util.Scanner;

public class BookArray {
    public static void main(String[] args) {
        Book[] books = new Book[10];
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter the title of book " + (i + 1) + ": ");
            String title = scanner.nextLine();
            System.out.print("Is the book fiction (F) or nonfiction (N)? ");
            String type = scanner.next();
            Book book;
            if (type.equalsIgnoreCase("F")) {
                book = new Fiction(title);
            } else if (type.equalsIgnoreCase("N")) {
                book = new NonFiction(title);
            } else {
                System.out.println("Invalid input. Please try again.");
                i--;
                continue;
            }
            books[i] = book;
        }

        for (Book book : books) {
            displayBookDetails(book);
        }
    }
    public static void displayBookDetails(Book book) {
        System.out.println("Title: " + book.getTitle());
        System.out.println("Price: $" + book.getPrice());
        System.out.println();
    }
}