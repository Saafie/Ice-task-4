import java.util.Arrays;
import java.util.Scanner;

public class DinnerEventDemo {

    public static void main(String[] args) {
        final int NUM_EVENTS = 4;
        DinnerEvent[] dinnerEvents = new DinnerEvent[NUM_EVENTS];
        Scanner input = new Scanner(System.in);


        for (int i = 0; i < NUM_EVENTS; i++) {
            System.out.println("Enter event number:");
            String eventNumber = input.nextLine();
            System.out.println("Enter number of guests:");
            int guests = input.nextInt();
            System.out.println("Enter entrée choice (0: Chicken, 1: Beef, 2: Vegetarian):");
            int entree = input.nextInt();
            System.out.println("Enter first side dish choice (0: Salad, 1: Soup, 2: Fries):");
            int side1 = input.nextInt();
            System.out.println("Enter second side dish choice (0: Salad, 1: Soup, 2: Fries):");
            int side2 = input.nextInt();
            System.out.println("Enter dessert choice (0: Cake, 1: Ice Cream, 2: Fruit):");
            int dessert = input.nextInt();
            input.nextLine();


            dinnerEvents[i] = new DinnerEvent(eventNumber, guests, entree, side1, side2, dessert);
        }

        boolean continueSorting = true;
        while (continueSorting) {
            System.out.println("\nHow would you like to sort the events?");
            System.out.println("1. By Event Number");
            System.out.println("2. By Number of Guests");
            System.out.println("3. By Event Type (using entrée choice)");
            System.out.println("4. Exit");
            int choice = input.nextInt();

            switch (choice) {
                case 1:
                    Arrays.sort(dinnerEvents, (e1, e2) -> e1.getEventNumber().compareTo(e2.getEventNumber()));
                    break;
                case 2:
                    Arrays.sort(dinnerEvents, (e1, e2) -> Integer.compare(e1.getGuests(), e2.getGuests()));
                    break;
                case 3:
                    Arrays.sort(dinnerEvents, (e1, e2) -> e1.getEntree().compareTo(e2.getEntree()));
                    break;
                case 4:
                    continueSorting = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    continue;
            }

            if (choice != 4) {
                for (DinnerEvent event : dinnerEvents) {
                    System.out.println("Event " + event.getEventNumber() + ": " + event.getGuests() + " guests, Menu: " + event.getMenu());
                }
            }
        }

        input.close();
    }
}
