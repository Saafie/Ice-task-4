import java.util.ArrayList;
import java.util.Collections;

public abstract class CardGame {
    protected ArrayList<Question3> deck;
    protected int cardsDealt;

    public CardGame(int cardsDealt) {
        this.cardsDealt = cardsDealt;
        initializeDeck();
    }


    private void initializeDeck() {
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] values = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};
        deck = new ArrayList<>();

        for (String suit : suits) {
            for (String value : values) {
                deck.add(new Question3(suit, value));
            }
        }
    }

    public void shuffle() {
        Collections.shuffle(deck);
    }

    public abstract void displayDescription();
    public abstract void deal();
}
