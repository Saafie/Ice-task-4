
public abstract class Question2 {
    protected int eyes;
    protected int legs;
    protected String planet;

    public Question2(int eyes, int legs, String planet) {
        this.eyes = eyes;
        this.legs = legs;
        this.planet = planet;
    }

    @Override
    public String toString() {
        return "This alien has " + eyes + " eyes, " + legs + " legs, and comes from the planet " + planet + ".";
    }
    public class Martian extends Question2 {

        public Martian() {
            super(4, 2, "Mars");
        }

        @Override
        public String toString() {
            return "Martian: " + super.toString();
        }
    }
    public class Jupiterian extends Question2 {

        public Jupiterian() {
            super(2, 6, "Jupiter");
        }

        @Override
        public String toString() {
            return "Jupiterian: " + super.toString();
        }
    }

}
