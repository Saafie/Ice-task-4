public class LessonWithRental extends Rental {
    private boolean lessonRequired;
    private int equipmentType;


    private final String[] equipmentTypes = {
            "Personal Watercraft", "Pontoon Boat", "Rowboat", "Canoe",
            "Kayak", "Beach Chair", "Umbrella", "Surfboard"
    };

    private final String[] instructors = {
            "John", "Sara", "Mike", "Anna", "David", "Emily", "Laura", "Jack"
    };


    public LessonWithRental(String contractNumber, int rentalMinutes, int equipmentType) {
        super(contractNumber, rentalMinutes);
        this.equipmentType = equipmentType;


        if (equipmentType == 0 || equipmentType == 1) {
            lessonRequired = true;
        } else {
            lessonRequired = false;
        }
    }


    public String getInstructor() {
        String lessonMessage = lessonRequired ? "requires a lesson" : "does not require a lesson";
        return "Equipment: " + equipmentTypes[equipmentType] +
                ", Lesson: " + lessonMessage +
                ", Instructor: " + instructors[equipmentType];
    }

    public boolean isLessonRequired() {
        return lessonRequired;
    }

    public String getEquipmentType() {
        return equipmentTypes[equipmentType];
    }

    public String getInstructorName() {
        return instructors[equipmentType];
    }
}
