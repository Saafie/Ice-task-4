
public class DinnerEvent extends Event {
    private int entreeChoice;
    private int sideDish1Choice;
    private int sideDish2Choice;
    private int dessertChoice;

    private final String[] entrees = {"Chicken", "Beef", "Vegetarian"};
    private final String[] sideDishes = {"Salad", "Soup", "Fries"};
    private final String[] desserts = {"Cake", "Ice Cream", "Fruit"};


    public DinnerEvent(String eventNumber, int guests, int entreeChoice, int sideDish1Choice, int sideDish2Choice, int dessertChoice) {
        super(eventNumber, guests);
        this.entreeChoice = entreeChoice;
        this.sideDish1Choice = sideDish1Choice;
        this.sideDish2Choice = sideDish2Choice;
        this.dessertChoice = dessertChoice;
    }


    public String getMenu() {
        return "Entrée: " + entrees[entreeChoice] +
                ", Side Dish 1: " + sideDishes[sideDish1Choice] +
                ", Side Dish 2: " + sideDishes[sideDish2Choice] +
                ", Dessert: " + desserts[dessertChoice];
    }

    public String getEntree() {
        return entrees[entreeChoice];
    }

    public String getSideDish1() {
        return sideDishes[sideDish1Choice];
    }

    public String getSideDish2() {
        return sideDishes[sideDish2Choice];
    }

    public String getDessert() {
        return desserts[dessertChoice];
    }
}
