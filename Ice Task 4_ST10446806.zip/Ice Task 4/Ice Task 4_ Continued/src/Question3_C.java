public class Poker extends CardGame {

    public Poker() {
        super(5); // 5 cards for poker
    }

    @Override
    public void displayDescription() {
        System.out.println("Poker is a game where each player is dealt 5 cards.");
    }

    @Override
    public void deal() {
        shuffle();
        System.out.println("Dealing 5 cards to the player:");
        for (int i = 0; i < cardsDealt; i++) {
            System.out.println(deck.get(i));
        }
    }
    public class Bridge extends CardGame {

        public Bridge() {
            super(13);
        }

        @Override
        public void displayDescription() {
            System.out.println("Bridge is a game where each player is dealt 13 cards.");
        }

        @Override
        public void deal() {
            shuffle();
            System.out.println("Dealing 13 cards to the player:");
            for (int i = 0; i < cardsDealt; i++) {
                System.out.println(deck.get(i));
            }
        }
    }
    public class PlayCardGames {

        public static void main(String[] args) {

            CardGame poker = new Poker();
            poker.displayDescription();
            poker.deal();


            CardGame bridge = new Bridge();
            bridge.displayDescription();
            bridge.deal();
        }
    }


}
