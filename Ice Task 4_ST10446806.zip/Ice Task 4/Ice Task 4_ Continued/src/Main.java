import java.util.Random;

public class Main {

    protected int value;

    private Random random;

    public Main() {
        random = new Random();
        roll();
    }

    public void roll() {
        value = random.nextInt(6) + 1;
    }

    public int getValue() {
        return value;
    }
    public class LoadedDie extends Main {

        @Override
        public void roll() {

            value = random.nextInt(5) + 2;
        }
    }
    public class TestLoadedDie {

        public static void main(String[] args) {
            int die1Wins = 0;
            int die2Wins = 0;
            int dieVsLoadedWins = 0;
            int loadedDieWins = 0;

            Die die1 = new Die();
            Die die2 = new Die();
            LoadedDie loadedDie = new LoadedDie();

            // Roll two Die objects against each other 1,000 times
            for (int i = 0; i < 1000; i++) {
                die1.roll();
                die2.roll();

                if (die1.getValue() > die2.getValue()) {
                    die1Wins++;
                } else if (die2.getValue() > die1.getValue()) {
                    die2Wins++;
                }
            }

            // Roll a Die object against a LoadedDie 1,000 times
            for (int i = 0; i < 1000; i++) {
                die1.roll();
                loadedDie.roll();

                if (die1.getValue() > loadedDie.getValue()) {
                    dieVsLoadedWins++;
                } else if (loadedDie.getValue() > die1.getValue()) {
                    loadedDieWins++;
                }
            }

            // Display the results
            System.out.println("Die vs Die:");
            System.out.println("Die 1 wins: " + die1Wins);
            System.out.println("Die 2 wins: " + die2Wins);

            System.out.println("\nDie vs LoadedDie:");
            System.out.println("Die wins: " + dieVsLoadedWins);
            System.out.println("LoadedDie wins: " + loadedDieWins);
        }
    }

}
