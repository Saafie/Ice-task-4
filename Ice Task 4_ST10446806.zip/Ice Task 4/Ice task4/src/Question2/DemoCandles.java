package Question2;

import java.util.Scanner;

public class DemoCandles {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        ScentedCandle myCandle = new ScentedCandle();

        System.out.print("Enter Colour: ");
        String colour = scanner.next();;
        myCandle.setColor(colour);

        System.out.print("Enter Height in Inches: ");
        int height = Integer.parseInt(scanner.next());
        myCandle.setHeight(height);



        while(true){
            System.out.print("Options:" + "\n"+"1. Gardenia" + "\n"+ "2. Lavender"+"\n"+"3. Rose"+ "\n"+"4. Sunflower"+ "\n");
            String scent = scanner.next();

        if(scent.contains("1") || scent.contains("Gardenia")){
            myCandle.setScent("Gardenia");
            break;
        }
        else if(scent.contains("2") || scent.contains("Lavender")){
            myCandle.setScent("Lavender");
            break;
        }else if(scent.contains("3") || scent.contains("Rose")){
            myCandle.setScent("Rose");
            break;}
        else if(scent.contains("4") || scent.contains("Sunflower")){
                myCandle.setScent("Sunflower");
            break;}
        else{System.out.print("Retry");}
        }


        System.out.println(  "Colour: " + myCandle.getColor() +"\n"+ "Height in Inches: " +myCandle.getHeight() +  "\n"+ "Price: $" +myCandle.getPrice() + "\n"+ "Candle Scent: " + myCandle.getScent());

    }
}
