package Question2;

public class ScentedCandle extends Candle {
    private String scent;

    public void setScent(String scent){
     this.scent = scent;
    }
    public String getScent(){
        return scent;
    }

    @Override
    //overrides and calculates new price
    public int getPrice(){
       int price = (getHeight()*3);
       return price;
    }
}
