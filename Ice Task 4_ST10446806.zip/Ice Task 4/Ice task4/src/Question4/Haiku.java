package Question4;

public class Haiku extends Poem {
    public Haiku(String name) {
        super(name, 3);//constant value
    }
}
