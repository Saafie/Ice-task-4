package Question4;

import java.util.Scanner;

public class DemoPoems {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the type of poem"+"\n"+ "1. Couplet" + "\n"+"2. Limerick"+"\n"+"3. Haiku" +"\n"+"4. Plain Poem"+"\n");
        int poemType = scanner.nextInt();//saves the new line info
        scanner.nextLine();

        while (poemType < 1 || poemType > 4) {
            System.out.println("Invalid input. Please enter a number between 1 and 4.");
            System.out.print("Enter the type of poem"+"\n"+ "1. Couplet" + "\n"+"2. Limerick"+"\n"+"3. Haiku" +"\n"+"4. Plain Poem):"+"\n");
            poemType = scanner.nextInt();//saves the new line info
            scanner.nextLine();
        }

        System.out.print("Enter the title of the poem: ");
        String title = scanner.nextLine();

        Poem poem;

        if (poemType == 1) {
            poem = new Couplet(title);
        } else if (poemType == 2) {
            poem = new Limerick(title);
        } else if (poemType == 3) {
            poem = new Haiku(title);
        } else {
            System.out.print("Enter the number of lines: ");
            int numLines = scanner.nextInt();
            poem = new Poem(title, numLines);
        }

        System.out.println("\n" + "-------------------------------"+ "\n"+"Poem details:"+"\n" + "-------------------------------");
        System.out.println("Name: " + poem.getPoem());
        System.out.println("Lines: " + poem.getLines());

        scanner.close();  // Close the scanner
    }}