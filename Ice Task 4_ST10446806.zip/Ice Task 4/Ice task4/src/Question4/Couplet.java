package Question4;

public class Couplet extends Poem {

    public Couplet(String name) {
        super(name, 2);//constant value
    }}


