package Question5;

public class BaseballGame {
    private String team1;
    private String team2;
    private final int INNINGS = 9;
    private int[][] scores;

    public BaseballGame(String team1, String team2) {
        this.team1 = team1;
        this.team2 = team2;
        scores = new int[2][INNINGS];
    }


    public void setTeam1(String team1) {
        this.team1 = team1;
    }

    public void setTeam2(String team2) {
        this.team2 = team2;
    }

    public String getTeam1() {
        return team1;
    }

    public String getTeam2() {
        return team2;
    }


    public void setScore(String team, int inning, int score) {
        if (inning < 1 || inning > INNINGS) {
            System.out.println("Invalid inning.");
            return;
        }
        if (team.equals(team1)) {
            scores[0][inning - 1] = score;
        } else if (team.equals(team2)) {
            scores[1][inning - 1] = score;
        } else {
            System.out.println("Invalid team.");
        }
    }


    public int getScore(String team, int inning) {
        if (team.equals(team1)) {
            return scores[0][inning - 1];
        } else if (team.equals(team2)) {
            return scores[1][inning - 1];
        } else {
            return -1; // Invalid team
        }
    }

    public int getTotalScore(String team) {
        int total = 0;
        if (team.equals(team1)) {
            for (int score : scores[0]) {
                total += score;
            }
        } else if (team.equals(team2)) {
            for (int score : scores[1]) {
                total += score;
            }
        }
        return total;
    }
    public static class HighSchoolBaseballGame extends BaseballGame {
        private final int INNINGS = 7;

        public HighSchoolBaseballGame(String team1, String team2) {
            super(team1, team2);
        }


        @Override
        public void setScore(String team, int inning, int score) {
            if (inning < 1 || inning > INNINGS) {
                System.out.println("Invalid inning. High school games have 7 innings.");
                return;
            }
            super.setScore(team, inning, score);
        }
    }
}