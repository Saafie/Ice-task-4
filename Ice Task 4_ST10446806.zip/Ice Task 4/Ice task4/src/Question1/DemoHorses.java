package Question1;

import Question2.Candle;

import java.util.Scanner;

public class DemoHorses {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        RaceHorse myHorse = new RaceHorse();

        System.out.print("Enter Name: ");
        String name = scanner.next();
        myHorse.setName(name); //sets the name to the name entered

        System.out.print("Enter Colour: ");
        String colour = scanner.next();;
        myHorse.setColor(colour);//sets the colour to the colour entered

        System.out.print("Enter Birth year: ");
        int birthYear = Integer.parseInt(scanner.next());;
        myHorse.setBirthYear(birthYear);//sets the birth year to the birth year entered


        System.out.print("Enter Race: ");
        int race = Integer.parseInt(scanner.next());;
        myHorse.setRace(String.valueOf(race));//sets the race to the race entered

//Displays
        System.out.print("\n"+"Horse Details"+ "\n"+ "-------------------------"+ "\n"+"Horse Name: "+ myHorse.getName()+"\n" + "Horse Colour: " + myHorse.getColor() +"\n" + "Birth year: " + myHorse.getBirthYear()+ "\n" + "Number of Races: " +myHorse.getRaces());
        scanner.close();//closes scanner


}}
