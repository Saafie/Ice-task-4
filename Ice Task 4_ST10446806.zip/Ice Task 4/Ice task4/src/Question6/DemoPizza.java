package Question6;

import java.util.Scanner;

public class DemoPizza {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] toppings = new String[10];
        int numToppings = 0;
        String input;

        // Prompt user to enter toppings
        System.out.println("Enter pizza toppings (type QUIT to stop):");
        while (numToppings < 10) {
            input = scanner.nextLine();
            if (input.equalsIgnoreCase("QUIT")) {
                break;
            }
            toppings[numToppings] = input;
            numToppings++;
        }

        System.out.println("Is this pizza for delivery? (yes/no):");
        String delivery = scanner.nextLine();

        Pizza pizza;

        if (delivery.equalsIgnoreCase("yes")) {

            System.out.println("Enter delivery address:");
            String address = scanner.nextLine();
            pizza = new DeliveryPizza(toppings, numToppings, address);
        } else {
            pizza = new Pizza(toppings, numToppings);
        }


        System.out.println(pizza.toString());
    }
}
